import React, { useEffect, useRef, useState } from "react";
import { createRender, useModelState } from "@anywidget/react";

import type { DictionaryState, MapViewState } from "../shared/types";
import type { GoToTarget2D } from "@arcgis/core/views/types.js";

import { arcgisImport, configureArcGisCdn } from "../shared/arcgis-cdn";
import { addMediaLayer, type LocalImageState } from "../shared/media-layer";
import { applySmartMapping } from "../shared/smart-mapping";
import {
  type TimeSliderConfig,
  syncTimeSliderConfig,
} from "../shared/time-slider";
import { initEsriConfig, initAuth } from "../shared/utils";

import "../widget.css";

// Because we are using the CDN, we have to define the constructors and modules for the different types
// that we will be using in the widget.
// We will load these dynamically from the CDN when needed via arcgisImport, which is a wrapper
// around dynamic import that ensures the ArcGIS API is loaded first.
type ExtentCtor = typeof import("@arcgis/core/geometry/Extent.js").default;
type PointCtor = typeof import("@arcgis/core/geometry/Point.js").default;
type WebMapCtor = typeof import("@arcgis/core/WebMap.js").default;
type ProjectOperatorModule =
  typeof import("@arcgis/core/geometry/operators/projectOperator.js");

const MapWidgetView: React.FC = () => {
  // Model state variables
  // This section exposes all the model state variables that the widget needs to react to.
  // These useModelState hooks subscribe the component to changes in the corresponding Python model attributes.
  // They also allow to mutate the state from within the component (e.g. in response to map events)
  // which will trigger updates back in the Python model and re-render the component with the new state.
  // The naming convention of prefixing with an underscore is just to visually distinguish these as "model state" variables,
  // but it's not required.

  // Accessing constants using useModelState (traitlets on the python side)
  const [_js_api_path] = useModelState<string>("js_api_path");

  const [_portal_token] = useModelState<string>("_portal_token");
  const [_auth_mode] = useModelState<string>("_auth_mode");
  const [_portal_rest_url] = useModelState<string>("_portal_rest_url");
  const [_proxy_rule] = useModelState<Record<string, string>>("_proxy_rule");
  const [_username] = useModelState<string>("_username");
  const [_show_legend] = useModelState<boolean>("_show_legend");
  const [_show_bookmarks] = useModelState<boolean>("_show_bookmarks");
  const [_show_layer_list] = useModelState<boolean>("_show_layer_list");
  const [_show_time_slider] = useModelState<boolean>("_show_time_slider");
  const [_time_slider_layer] = useModelState<number>("_time_slider_layer");
  const [_time_slider_full_extent] = useModelState<Record<string, number>>(
    "_time_slider_full_extent",
  );
  const [_time_slider_time_interval] = useModelState<
    Record<string, number | string>
  >("_time_slider_time_interval");
  const [_webmap_dict] = useModelState<DictionaryState>("_webmap_dict");
  const [_viewState, setViewState] = useModelState<MapViewState>("_view_state");
  const [_theme] = useModelState<string>("theme");
  const [_smart_mapping_renderer, setSMRenderer] =
    useModelState<DictionaryState>("_smart_mapping_renderer");
  const [_smart_mapping_params] = useModelState<DictionaryState>(
    "_smart_mapping_params",
  );
  const [_local_image_data] =
    useModelState<LocalImageState>("_local_image_data");
  const [_raster_to_media_layer, setMediaLayer] =
    useModelState<DictionaryState>("_raster_to_media_layer");

  // Effects and handlers
  // The section below contains React state and effects that manage the lifecycle of the ArcGIS map component
  // and synchronize it with the Python model state.

  const mapElementRef = useRef<HTMLArcgisMapElement | null>(null);

  const [timeSliderConfig, setTimeSliderConfig] =
    useState<TimeSliderConfig | null>(null);

  // True while the effect is echoing a Python model update back through the map element.
  // Prevents the arcgisViewChange handler from triggering another effect run.
  // NOTE: relies on animate:false — goTo settles synchronously so no inter-generation race is possible.
  // If animated goTo is ever needed, a generation counter will be required here.
  const suppressNextEffect = useRef(false);

  // Incremented each time arcgisViewReadyChange fires (initial load + every map replacement).
  // Used as a dep so view-dependent effects re-run when the view becomes available.
  const [viewReadyCount, setViewReadyCount] = useState(0);

  // configureArcGisCdn enforces page-wide call-once semantics — only different URLs warn.
  // Changing js_api_path at runtime is not supported.
  // Must be the FIRST effect so the CDN URL is set before any arcgisImport call below.
  useEffect(() => {
    configureArcGisCdn(_js_api_path);
  }, []);

  // Configures esriConfig globals — runs once at startup (_portal_rest_url is frozen at mount)
  useEffect(() => {
    void initEsriConfig(_portal_rest_url);
  }, []);

  // Registers auth credentials and proxy rules — runs once at startup
  useEffect(() => {
    void initAuth(
      _auth_mode,
      _portal_rest_url,
      _portal_token,
      _username,
      _proxy_rule,
    );
  }, []);

  // The model WebMap has changed — apply it to the component.
  // This will trigger arcgisViewReadyChange when the new view is ready.
  useEffect(() => {
    if (!_webmap_dict || !mapElementRef.current) return;

    const controller = new AbortController();
    void applyWebMapChange(
      mapElementRef.current,
      _webmap_dict,
      controller.signal,
    );
    return () => controller.abort();
  }, [_webmap_dict] /* Do not include viewReadyCount here otherwise infinite loop */);

  // Applies incoming model view state to the map (Python → map).
  // The arcgisViewChange event owns the write-back; suppressNextEffect blocks the echo re-run.
  // viewReadyCount gates execution: arcgisViewReadyChange is the authoritative signal that
  // the view exists and is ready for programmatic updates.
  useEffect(() => {
    if (!mapElementRef.current?.ready || !_viewState) return;

    if (suppressNextEffect.current) {
      suppressNextEffect.current = false;
      return;
    }

    const controller = new AbortController();
    void applyViewStateChange(mapElementRef.current, _viewState, controller.signal);
    return () => controller.abort();
  }, [_viewState, viewReadyCount]);

  // Builds the time slider config from Python model values and stores it in
  // state. React then passes it declaratively as JSX props — no DOM ref needed.
  useEffect(() => {
    if (!mapElementRef.current?.ready) return;

    const controller = new AbortController();
    void syncTimeSliderConfig(mapElementRef.current, {
      showTimeSlider: _show_time_slider,
      timeSliderLayer: _time_slider_layer,
      timeSliderFullExtent: _time_slider_full_extent,
      timeSliderTimeInterval: _time_slider_time_interval,
      setTimeSliderConfig,
      signal: controller.signal,
    });
    return () => controller.abort();
  }, [
    _show_time_slider,
    _time_slider_full_extent,
    _time_slider_layer,
    _time_slider_time_interval,
    viewReadyCount,
  ]);

  // Adds a media layer from a local image source (Raster Workflow)
  useEffect(() => {
    if (
      !mapElementRef.current?.ready ||
      !_local_image_data?.image ||
      !_local_image_data?.extent
    )
      return;
      
    const controller = new AbortController();
    void addMediaLayer(
      mapElementRef.current,
      _local_image_data,
      setMediaLayer,
      controller.signal,
    );
    return () => controller.abort();
  }, [_local_image_data, viewReadyCount]);

  // Creates and applies a smart mapping renderer
  useEffect(() => {
    if (
      !mapElementRef.current?.ready ||
      !_smart_mapping_params ||
      Object.keys(_smart_mapping_params).length === 0
    )
      return;
    const controller = new AbortController();
    void applySmartMapping(
      mapElementRef.current,
      _smart_mapping_params,
      setSMRenderer,
      controller.signal,
    );
    return () => controller.abort();
  }, [_smart_mapping_params, viewReadyCount]);

  return (
    <arcgis-map
      className={`map-container ${_theme === "dark" ? "calcite-mode-dark" : "calcite-mode-light"}`}
      ref={mapElementRef}
      attributionMode={_theme === "dark" ? "dark" : "light"}
      onarcgisViewReadyChange={() => setViewReadyCount((c) => c + 1)}
      onarcgisViewChange={(e) => {
        if (!e.target.stationary || !e.target.ready) return;

        // Event is the single owner of model writes (both map-initiated and Python goTo echo-back).
        // Suppress the next effect run so the write-back doesn't re-trigger applyViewStateChange.
        suppressNextEffect.current = true;
        const { extent, zoom, center, scale, rotation } = e.target;

        setViewState({
          extent: extent.toJSON(),
          zoom: Math.round(zoom),
          center: [center.latitude ?? 0, center.longitude ?? 0],
          scale,
          rotation,
        });
      }}
    >
      <arcgis-zoom slot="top-left" />
      {_show_legend && <arcgis-expand slot="top-right" group="essential-tools"><arcgis-legend /></arcgis-expand>}
      {_show_bookmarks && <arcgis-expand slot="top-right" group="essential-tools"><arcgis-bookmarks /></arcgis-expand>}
      {_show_layer_list && <arcgis-expand slot="top-right" group="essential-tools"><arcgis-layer-list /></arcgis-expand>}
      {_show_time_slider && (
        <arcgis-time-slider
          slot="bottom-right"
          mode={timeSliderConfig?.mode}
          fullTimeExtent={timeSliderConfig?.fullTimeExtent}
          timeExtent={timeSliderConfig?.timeExtent}
          stops={timeSliderConfig?.stops}
        />
      )}
    </arcgis-map>
  );
};

/**
 * Creates a new WebMap from the provided JSON and applies it to the map component.
 * This will trigger the component to create a new view, and the arcgisViewReadyChange event
 * will fire when the view is ready.
 * The effect that depends on the view will re-run at that time, ensuring that any view-dependent
 * configuration is applied to the new view.
 */
async function applyWebMapChange(
  mapElement: HTMLArcgisMapElement,
  webmapDict: DictionaryState,
  signal: AbortSignal,
): Promise<void> {
  const [WebMap] = await arcgisImport<[WebMapCtor]>(["@arcgis/core/WebMap.js"]);
  if (signal.aborted) return;
  
  // Setting .map triggers the component to (re)create its view.
  // arcgisViewReadyChange fires when ready — both on initial load and map replacement.
  mapElement.map = WebMap.fromJSON(webmapDict);
}

/**
 * Apply the view state changes coming from the Python model to the map view.
 * This function is called when the _view_state model state changes.
 */
async function applyViewStateChange(
  mapElement: HTMLArcgisMapElement,
  viewState: MapViewState,
  signal: AbortSignal,
): Promise<void> {
  const [Extent, Point, projectOperator] = await arcgisImport<
    [ExtentCtor, PointCtor, ProjectOperatorModule]
  >([
    "@arcgis/core/geometry/Extent.js",
    "@arcgis/core/geometry/Point.js",
    "@arcgis/core/geometry/operators/projectOperator.js",
  ]);

  if (signal.aborted) return;

  const { center, zoom, rotation, scale, extent } = viewState;

  if (rotation !== undefined && rotation !== mapElement.rotation) {
    mapElement.rotation = rotation;
  }

  const extentObj = extent ? Extent.fromJSON(extent) : null;
  let goToTarget: GoToTarget2D | null = null;

  if (extentObj) {
    if (!mapElement.extent?.equals(extentObj)) {
      goToTarget = { target: extentObj };
    }
  } else {
    const opts: {
      center?: InstanceType<PointCtor>;
      scale?: number;
      zoom?: number;
    } = {};
    if (
      Array.isArray(center) &&
      (center[1] !== mapElement.center.longitude ||
        center[0] !== mapElement.center.latitude)
    ) {
      if (!projectOperator.isLoaded()) {
        await projectOperator.load();
        if (signal.aborted) return;
      }
      opts.center = new Point({
        longitude: center[1],
        latitude: center[0],
        spatialReference: mapElement.spatialReference,
      });
    }
    if (scale !== undefined && scale !== mapElement.scale) {
      opts.scale = scale;
    } else if (zoom !== undefined && zoom !== mapElement.zoom) {
      opts.zoom = zoom;
    }
    if (Object.keys(opts).length > 0) {
      goToTarget = opts as GoToTarget2D;
    }
  }

  if (goToTarget === null) return;

  try {
    await mapElement.goTo(goToTarget, { animate: false });
  } catch {
    // goTo throws if interrupted by a subsequent navigation — not an error
  }
  // arcgisViewChange fires before this continuation (confirmed: stationary precedes Promise resolution).
  // The event handler owns the write-back to the model — nothing to do here.
}

const render = createRender(MapWidgetView);

export default { render };
