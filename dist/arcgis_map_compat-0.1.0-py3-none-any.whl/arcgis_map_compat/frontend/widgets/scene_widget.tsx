import React, { useEffect, useRef, useState } from "react";
import { createRender, useModelState } from "@anywidget/react";

import type { GoToTarget3D } from "@arcgis/core/views/types.js";
import type {
  DictionaryState,
  SceneViewState as ViewState,
} from "../shared/types";

import { arcgisImport, configureArcGisCdn } from "../shared/arcgis-cdn";
import {
  type TimeSliderConfig,
  syncTimeSliderConfig,
} from "../shared/time-slider";
import { initEsriConfig, initAuth } from "../shared/utils";

import "../widget.css";

// Because we are using the CDN, we have to define the constructors and modules for the different types
// that we will be using in the widget.
// We will load these dynamically from the CDN when needed via arcgisImport, which is a wrapper
// around dynamic import that ensures the ArcGIS API is loaded first.
type ExtentCtor = typeof import("@arcgis/core/geometry/Extent.js").default;
type PointCtor = typeof import("@arcgis/core/geometry/Point.js").default;
type CameraCtor = typeof import("@arcgis/core/Camera.js").default;
type ProjectOperatorModule =
  typeof import("@arcgis/core/geometry/operators/projectOperator.js");
type WebSceneCtor = typeof import("@arcgis/core/WebScene.js").default;

const SceneWidgetView: React.FC = () => {
  // #region Model state variables
  // This section exposes all the model state variables that the widget needs to react to.
  // These useModelState hooks subscribe the component to changes in the corresponding Python model attributes.
  // They also allow to mutate the state from within the component (e.g. in response to scene events)
  // which will trigger updates back in the Python model and re-render the component with the new state.
  // The naming convention of prefixing with an underscore is just to visually distinguish these as "model state" variables,
  // but it's not required.

  const [jsApiPath] = useModelState<string>("js_api_path");

  const [_portal_token] = useModelState<string>("_portal_token");
  const [_auth_mode] = useModelState<string>("_auth_mode");
  const [_portal_rest_url] = useModelState<string>("_portal_rest_url");
  const [_proxy_rule] = useModelState<Record<string, string>>("_proxy_rule");
  const [_username] = useModelState<string>("_username");
  const [_show_legend] = useModelState<boolean>("_show_legend");
  const [_show_layer_list] = useModelState<boolean>("_show_layer_list");
  const [_show_daylight] = useModelState<boolean>("_show_daylight");
  const [_show_weather] = useModelState<boolean>("_show_weather");
  const [_show_time_slider] = useModelState<boolean>("_show_time_slider");
  const [_time_slider_layer] = useModelState<number>("_time_slider_layer");
  const [_time_slider_full_extent] = useModelState<Record<string, number>>(
    "_time_slider_full_extent",
  );
  const [_time_slider_time_interval] = useModelState<
    Record<string, number | string>
  >("_time_slider_time_interval");
  const [_webscene_dict] = useModelState<DictionaryState>("_webscene_dict");
  const [_viewState, setViewState] = useModelState<ViewState>("_view_state");
  const [_theme] = useModelState<string>("theme");
  //#endregion

  // #region Effects and handlers
  // The section below contains React state and effects that manage the lifecycle of the ArcGIS scene component
  // and synchronize it with the Python model state.

  const sceneComponentRef = useRef<HTMLArcgisSceneElement | null>(null);
  const [timeSliderConfig, setTimeSliderConfig] =
    useState<TimeSliderConfig | null>(null);

  // True while the effect is echoing a Python model update back through the scene element.
  // Prevents the arcgisViewChange handler from triggering another effect run.
  // NOTE: relies on animate:false — goTo settles synchronously so no inter-generation race is possible.
  // If animated goTo is ever needed, a generation counter will be required here.
  const suppressNextEffect = useRef(false);

  // Incremented each time arcgisViewReadyChange fires (initial load + every scene replacement).
  // Used as a dep so view-dependent effects re-run when the view becomes available.
  const [viewReadyCount, setViewReadyCount] = useState(0);

  // configureArcGisCdn enforces page-wide call-once semantics — only different URLs warn.
  // Changing js_api_path at runtime is not supported.
  // Must be the FIRST effect so the CDN URL is set before any arcgisImport call below.
  useEffect(() => {
    configureArcGisCdn(jsApiPath);
  }, [jsApiPath]);

  // Configures esriConfig globals — runs once at startup (js_api_path is frozen at mount)
  useEffect(() => {
    void initEsriConfig(_portal_rest_url);
  }, [_portal_rest_url]);

  // Registers auth credentials and proxy rules — runs once at startup
  useEffect(() => {
    void initAuth(
      _auth_mode,
      _portal_rest_url,
      _portal_token,
      _username,
      _proxy_rule,
    );
  }, []);

  // The model WebScene has changed — apply it to the component.
  // This will trigger arcgisViewReadyChange when the new view is ready.
  useEffect(
    () => {
      const controller = new AbortController();
      void applyWebSceneChange(
        sceneComponentRef.current,
        _webscene_dict,
        controller.signal,
      );
      return () => controller.abort();
    },
    [
      _webscene_dict,
    ] /* Do not include viewReadyCount here otherwise infinite loop */,
  );

  // Applies incoming model view state to the scene (Python → scene).
  // The arcgisViewChange event owns the write-back; suppressNextEffect blocks the echo re-run.
  // viewReadyCount gates execution: arcgisViewReadyChange is the authoritative signal that
  // the view exists and is ready for programmatic updates.
  useEffect(() => {
    const sceneElement = sceneComponentRef.current;
    if (!sceneElement?.ready || !_viewState) return;

    if (suppressNextEffect.current) {
      suppressNextEffect.current = false;
      return;
    }

    const controller = new AbortController();
    void applyViewStateChange(sceneElement, _viewState, controller.signal);
    return () => controller.abort();
  }, [_viewState, viewReadyCount]);

  // Builds the time slider config from Python model values and stores it in
  // state. React then passes it declaratively as JSX props — no DOM ref needed.
  useEffect(() => {
    const sceneComponent = sceneComponentRef.current;
    if (!sceneComponent || !sceneComponent.ready) return;

    const controller = new AbortController();
    void syncTimeSliderConfig(sceneComponent, {
      showTimeSlider: _show_time_slider,
      timeSliderLayer: _time_slider_layer,
      timeSliderFullExtent: _time_slider_full_extent,
      timeSliderTimeInterval: _time_slider_time_interval,
      setTimeSliderConfig,
      signal: controller.signal,
    });
    return () => controller.abort();
  }, [
    _show_time_slider,
    _time_slider_full_extent,
    _time_slider_layer,
    _time_slider_time_interval,
    viewReadyCount,
  ]);
  // #endregion

  return (
    <arcgis-scene
      className={`scene-container ${_theme === "dark" ? "calcite-mode-dark" : "calcite-mode-light"}`}
      ref={sceneComponentRef}
      attributionMode={_theme === "dark" ? "dark" : "light"}
      onarcgisViewReadyChange={() => setViewReadyCount((c) => c + 1)}
      onarcgisViewChange={(e) => {
        if (!e.target.stationary || !e.target.ready) return;
        // Event is the single owner of model writes (both scene-initiated and Python goTo echo-back).
        // Suppress the next effect run so the write-back doesn't re-trigger applyViewStateChange.
        suppressNextEffect.current = true;
        syncViewStateFromElement(e.target, setViewState);
      }}
    >
      <arcgis-zoom slot="top-left" />
      <arcgis-navigation-toggle slot="top-left" visual-scale="m" />
      <arcgis-compass slot="top-left" />
      {_show_legend ? (
        <arcgis-expand slot="top-right" group="essential-tools">
          <arcgis-legend />
        </arcgis-expand>
      ) : null}
      {_show_layer_list ? (
        <arcgis-expand slot="top-right" group="essential-tools">
          <arcgis-layer-list />
        </arcgis-expand>
      ) : null}
      {_show_daylight ? (
        <arcgis-expand slot="top-right" group="essential-tools">
          <arcgis-daylight />
        </arcgis-expand>
      ) : null}
      {_show_weather ? (
        <arcgis-expand slot="top-right" group="essential-tools">
          <arcgis-weather />
        </arcgis-expand>
      ) : null}
      {_show_time_slider ? (
        <arcgis-time-slider
          slot="bottom-right"
          mode={timeSliderConfig?.mode}
          fullTimeExtent={timeSliderConfig?.fullTimeExtent}
          timeExtent={timeSliderConfig?.timeExtent}
          stops={timeSliderConfig?.stops}
        />
      ) : null}
    </arcgis-scene>
  );
};

function syncViewStateFromElement(
  sceneElement: HTMLArcgisSceneElement,
  setViewState: (state: ViewState) => void,
): void {
  const view = sceneElement.view;
  if (!view?.camera || !view.extent || !view.center) return;
  setViewState({
    camera: view.camera.toJSON(),
    zoom: Math.round(view.zoom),
    center: [view.center.latitude ?? 0, view.center.longitude ?? 0],
    extent: view.extent.toJSON(),
    scale: view.scale,
  });
}

/**
 * Apply the view state changes coming from the Python model to the scene view.
 * This function is called when the _view_state model state changes.
 */
async function applyViewStateChange(
  sceneElement: HTMLArcgisSceneElement,
  viewState: ViewState,
  signal: AbortSignal,
): Promise<void> {
  const view = sceneElement.view;
  if (!view) return;

  const [Extent, Point, Camera, projectOperator] = await arcgisImport<
    [ExtentCtor, PointCtor, CameraCtor, ProjectOperatorModule]
  >([
    "@arcgis/core/geometry/Extent.js",
    "@arcgis/core/geometry/Point.js",
    "@arcgis/core/Camera.js",
    "@arcgis/core/geometry/operators/projectOperator.js",
  ]);

  if (signal.aborted || sceneElement.view !== view) return;

  const { camera, center, zoom, scale, extent } = viewState;
  const extentObj = extent ? Extent.fromJSON(extent) : null;
  let goToTarget: GoToTarget3D | null = null;

  if (camera) {
    const currentCameraJson = view.camera?.toJSON?.() ?? null;
    if (!currentCameraJson || !deepEqual(currentCameraJson, camera)) {
      const point = new Point({
        x: camera.position.x,
        y: camera.position.y,
        z: camera.position.z,
        spatialReference: view.extent?.spatialReference,
      });
      goToTarget = new Camera({
        position: point,
        heading: camera.heading,
        tilt: camera.tilt,
      });
    }
  } else if (extentObj) {
    if (!view.extent?.equals(extentObj)) {
      goToTarget = { target: extentObj };
    }
  } else {
    const opts: {
      center?: InstanceType<PointCtor>;
      scale?: number;
      zoom?: number;
    } = {};
    if (
      Array.isArray(center) &&
      (center[1] !== view.center?.longitude ||
        center[0] !== view.center?.latitude)
    ) {
      if (!projectOperator.isLoaded()) {
        await projectOperator.load();
        if (signal.aborted || sceneElement.view !== view) return;
      }
      opts.center = new Point({
        longitude: center[1],
        latitude: center[0],
        spatialReference: view.spatialReference,
      });
    }
    if (scale !== undefined && scale !== view.scale) {
      opts.scale = scale;
    } else if (zoom !== undefined && zoom !== view.zoom) {
      opts.zoom = zoom;
    }
    if (Object.keys(opts).length > 0) {
      goToTarget = opts as GoToTarget3D;
    }
  }

  if (goToTarget === null) return;

  try {
    await view.goTo(goToTarget, { animate: false });
  } catch {
    // goTo throws if interrupted by a subsequent navigation — not an error
  }
  // arcgisViewChange fires before this continuation (same ordering as arcgis-map).
  // The event handler owns the write-back to the model — nothing to do here.
}

/**
 * Creates a new WebScene from the provided JSON and applies it to the scene component.
 * This will trigger the component to create a new view, and the arcgisViewReadyChange event
 * will fire when the view is ready.
 * The effect that depends on the view will re-run at that time, ensuring that any view-dependent
 * configuration is applied to the new view.
 */
async function applyWebSceneChange(
  sceneComponent: HTMLArcgisSceneElement | null,
  websceneDict: DictionaryState | null | undefined,
  signal: AbortSignal,
): Promise<void> {
  if (!sceneComponent || !websceneDict) return;

  const [WebScene] = await arcgisImport<[WebSceneCtor]>([
    "@arcgis/core/WebScene.js",
  ]);
  if (signal.aborted) return;
  // Setting .map triggers the component to (re)create its view.
  // arcgisViewReadyChange fires when ready — both on initial load and scene replacement.
  sceneComponent.map = WebScene.fromJSON(websceneDict);
}

function deepEqual(obj1: unknown, obj2: unknown): boolean {
  return JSON.stringify(sortKeys(obj1)) === JSON.stringify(sortKeys(obj2));
}

function sortKeys(obj: unknown): unknown {
  if (Array.isArray(obj)) {
    return obj.map(sortKeys);
  }
  if (obj && typeof obj === "object") {
    const record = obj as Record<string, unknown>;
    return Object.keys(record)
      .sort()
      .reduce(
        (acc, key) => {
          acc[key] = sortKeys(record[key]);
          return acc;
        },
        {} as Record<string, unknown>,
      );
  }
  return obj;
}

const render = createRender(SceneWidgetView);

export default { render };
