/**
 * Common types used across the map widget, including state representations for serialization between Python and the frontend.
 */
export type DictionaryState = Record<string, unknown>;

/**
 * Represents an extent that can be serialized to/from JSON.
 * Used to pass a state in between python and widget. 
 */
export interface ExtentState {
  xmin: number;
  ymin: number;
  xmax: number;
  ymax: number;
  spatialReference: {
    wkid: number;
    latestWkid: number;
  };
}


/**
 * Represents teh state of a view (MapView or SceneView) that can be serialized to/from JSON.
 * Used to pass a state in between python and widget.
 */
interface BaseViewState {
  zoom?: number;
  center?: [number, number];
  extent?: ExtentState;
  scale?: number;
}

/**
 * Represents the state of a MapView that can be serialized to/from JSON.
 * Used to pass a state in between python and widget.
 */
export interface MapViewState extends BaseViewState {
  rotation?: number;
}

/**
 * Represents the state of a SceneView that can be serialized to/from JSON.
 * Used to pass a state in between python and widget.
 */
export interface SceneViewState extends BaseViewState {
  camera?: {
    position: { x: number; y: number; z: number };
    heading: number;
    tilt: number;
  };
}

/**
 * Instead of forcing to pass HTMLArcgisMapElement everywhere, we can just pass the relevant properties (map and view) as a context object.
 * This also allows us to avoid issues with the type of view (MapView vs SceneView) by just passing the properties we need for our operations.
 * The map and view themselves can be null or undefined when they are not ready, so we need to account for that in our types.
 * This is used as the context for various operations that need access to the map and view, such as smart mapping and media layer management.
 */
export type MapContext2D = Pick<HTMLArcgisMapElement, "map" | "view">;
export type MapContext3D = Pick<HTMLArcgisSceneElement, "map" | "view">;
export type MapContext = MapContext2D | MapContext3D;