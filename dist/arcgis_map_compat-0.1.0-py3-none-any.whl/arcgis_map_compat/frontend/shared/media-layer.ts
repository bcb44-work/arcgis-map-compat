import { arcgisImport } from "./arcgis-cdn";

import type { ImageElementProperties } from "@arcgis/core/layers/support/ImageElement.js";
import type { DictionaryState, ExtentState, MapContext } from "./types";
import type MediaLayer from "@arcgis/core/layers/MediaLayer.js";

type ExtentCtor = typeof import("@arcgis/core/geometry/Extent.js").default;
type ExtentAndRotationGeoreferenceCtor =
  typeof import("@arcgis/core/layers/support/ExtentAndRotationGeoreference.js").default;
type ImageElementCtor =
  typeof import("@arcgis/core/layers/support/ImageElement.js").default;
type MediaLayerCtor =
  typeof import("@arcgis/core/layers/MediaLayer.js").default;

// HACK: The type below exposes undocumented API — may break with new SDK versions.
type MediaUtilsLike = {
  toControlPointsGeoreference: (
    extentGeoreference: unknown,
    width: number,
    height: number,
  ) => unknown;
};

// HACK: Using undocumented toJSON() method for serialization, which may break with new SDK versions.
type RuntimeSerializable = {
  toJSON: () => unknown;
};

export type LocalImageState = {
  image?: ImageElementProperties["image"];
  extent?: ExtentState;
  opacity?: number;
};

/**
 * Adds a media layer to the specified map element using the provided local image data.
 */
export async function addMediaLayer(
  { map }: MapContext,
  localImageData: LocalImageState,
  setMediaLayer: (layer: DictionaryState) => void,
  signal: AbortSignal,
): Promise<void> {
  if (!map || !localImageData.extent) return;

  const [
    Extent,
    ExtentAndRotationGeoreference,
    ImageElement,
    MediaLayer,
    mediaUtils,
  ] = await arcgisImport<
    [
      ExtentCtor,
      ExtentAndRotationGeoreferenceCtor,
      ImageElementCtor,
      MediaLayerCtor,
      MediaUtilsLike,
    ]
  >([
    "@arcgis/core/geometry/Extent.js",
    "@arcgis/core/layers/support/ExtentAndRotationGeoreference.js",
    "@arcgis/core/layers/support/ImageElement.js",
    "@arcgis/core/layers/MediaLayer.js",
    "@arcgis/core/layers/support/mediaUtils.js",
  ]);

  if (signal.aborted) return;

  const extentGeoreference = new ExtentAndRotationGeoreference({
    extent: Extent.fromJSON(localImageData.extent),
  });
  const controlPointsGeoreference = mediaUtils.toControlPointsGeoreference(
    extentGeoreference,
    400,
    400,
  );
  const imageElement = new ImageElement({
    image: localImageData.image,
    georeference:
      controlPointsGeoreference as ImageElementProperties["georeference"],
  });
  const mediaLayer = new MediaLayer({
    source: [imageElement],
    title: "Local Image Layer",
    opacity:
      typeof localImageData.opacity === "number"
        ? localImageData.opacity
        : undefined,
  });

  map.add(mediaLayer);
  mediaLayer
    .load()
    .then(() => {
      if (signal.aborted) return;
      const serialized = serializeRuntimeLayer(mediaLayer);
      if (!serialized) {
        console.error("Media layer serialization failed: toJSON() unavailable");
        return;
      }
      setMediaLayer(serialized);
    })
    .catch((error) => {
      console.error("Error loading media layer:", error);
    });
}

/**
 * Because this implementation on undocumented API, we defensively check for the presence of toJSON() and return null if it's not available,
 * which will cause the media layer state to be omitted from the serialized map state.
 */
function serializeRuntimeLayer(layer: MediaLayer): DictionaryState | null {
  if (!isRuntimeSerializable(layer)) {
    return null;
  }

  const json = layer.toJSON();
  if (!json || typeof json !== "object" || Array.isArray(json)) {
    return null;
  }

  return json as DictionaryState;
}

/**
 * Safeguard type check to ensure the value has a toJSON() method, which is required for serialization of runtime layers.
 */
function isRuntimeSerializable(value: unknown): value is RuntimeSerializable {
  return (
    typeof value === "object" &&
    value !== null &&
    "toJSON" in value &&
    typeof (value as RuntimeSerializable).toJSON === "function"
  );
}
