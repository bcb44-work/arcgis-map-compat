from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
import json
import math
import os
import pathlib
import uuid
from urllib.parse import unquote, urlsplit

import anywidget
from IPython.display import display
from pydantic import TypeAdapter
from traitlets import Bool, Dict, Int, Unicode, observe

from ._connection import GISContext
from .controls import LayerList, Legend
from .content_options import LayerOptions
from .dataclasses.models import geometry as _models_geometry
from .dataclasses.models import layers as _models_layers
from .dataclasses.models import mapping as _models_mapping
from .definitions._basemap_definitions import basemap_dict


class Map(anywidget.AnyWidget):
    """Visualization subset of the existing Map. Coordinates use [latitude, longitude]."""

    _esm = pathlib.Path(__file__).parent / "frontend" / "compat-host.js"
    _renderer_esm = Unicode(
        (pathlib.Path(__file__).parent / "static" / "map_widget.js").read_text(encoding="utf-8")
    ).tag(sync=True)

    _css = pathlib.Path(__file__).parent / "static" / "map_widget.css"

    _portal_token = Unicode("").tag(sync=True)

    _auth_mode = Unicode("").tag(sync=True)

    _portal_rest_url = Unicode("").tag(sync=True)

    _proxy_rule = Dict({}).tag(sync=True)

    _username = Unicode("").tag(sync=True)

    _show_legend = Bool(False).tag(sync=True)

    _show_bookmarks = Bool(False).tag(sync=True)

    _show_layer_list = Bool(False).tag(sync=True)

    _webmap_dict = Dict({}).tag(sync=True)

    _show_time_slider = Bool(False).tag(sync=True)

    _time_slider_layer = Int().tag(sync=True)

    _time_slider_full_extent = Dict({}).tag(sync=True)

    _time_slider_time_interval = Dict({}).tag(sync=True)

    _smart_mapping_renderer = Dict({}).tag(sync=True)

    _smart_mapping_params = Dict({}).tag(sync=True)

    _local_image_data = Dict({}).tag(sync=True)

    _raster_to_media_layer = Dict({}).tag(sync=True)  # only used by JS

    js_api_path = Unicode("").tag(sync=True)

    theme = Unicode("light").tag(sync=True)

    _view_state = Dict(default_value={}).tag(sync=True)

    def __init__(self, location=None, *, item=None, gis=None, **kwargs):
        connection = GISContext.from_gis(gis)
        self._gis = gis
        self._content = None
        self._basemap_manager = None

        if isinstance(item, str):
            if not hasattr(gis, "content"):
                raise ValueError("Resolving an item ID requires a GIS-like content manager.")
            item = gis.content.get(item)
            if item is None:
                raise ValueError("No item was found corresponding to this item ID.")
        if item is None:
            self.item = None
            self._webmap = _models_mapping.Webmap(
                operationalLayers=[],
                baseMap={
                    "baseMapLayers": deepcopy(basemap_dict["topo-vector"]),
                    "title": "Topographic",
                },
                spatialReference={"wkid": 102100, "latestWkid": 3857},
                bookmarks=[],
            )
        else:
            self.item = item
            data = dict(item) if isinstance(item, Mapping) else item.get_data()
            self._webmap = _models_mapping.Webmap.model_validate(deepcopy(data))
            if self._webmap.operational_layers is None:
                self._webmap.operational_layers = []

        super().__init__(**kwargs)
        self._portal_rest_url = connection.portal_url
        self._portal_token = connection.token
        self._auth_mode = "tokenBased" if connection.token else "anonymous"
        self._username = connection.username
        self._proxy_rule = dict(connection.proxy_rules)
        if not self.js_api_path:
            self.js_api_path = os.getenv("JSAPI_CDN", "")

        if location is not None:
            self.center = location
        elif item is None:
            # Retain the original default viewpoint.
            self.extent = {
                "spatialReference": {"wkid": 102100, "latestWkid": 3857},
                "xmin": -13034068.816148141,
                "ymin": 4021158.323305902,
                "xmax": -13014692.029477874,
                "ymax": 4036445.728962917,
            }
        self._update_source()

    def _ipython_display_(self):
        # ipywidgets 7 calls this hook directly and bypasses _repr_mimebundle_.
        self._update_source()
        data, metadata = super()._repr_mimebundle_()
        display(data, raw=True, metadata=metadata)

    @property
    def basemap(self):
        if self._basemap_manager is None:
            self._basemap_manager = BasemapManager(self)
        return self._basemap_manager

    @observe("_view_state")
    def _on_view_state_change(self, change):
        # This method will be called whenever the 'view_state' trait changes
        # Check the Initial State of the webmap. If the target geometry in the viewpoint is different, update it.
        # Don't update the webmap dict since we are dealing with a traitlets change
        new_extent = (
            _models_geometry.Extent(**change["new"].get("extent"))
            if change["new"].get("extent")
            else {}
        )
        # First time code is executed there might not be an initial state, if not set to None for old extent.
        old_extent = (
            (
                self._webmap.initial_state.dict()
                .get("viewpoint", {})
                .get("targetGeometry")
            )
            if self._webmap.initial_state
            else None
        )

        # Compare the new extent from the view state with the old extent from the webmap's initial state.
        # If there is no change in extent, no update to the initial state is needed.
        if not new_extent or json.dumps(old_extent, sort_keys=True) == json.dumps(
            new_extent.dict(), sort_keys=True
        ):
            # No change in extent, do nothing
            return
        if self._webmap.initial_state:
            self._webmap.initial_state.viewpoint.target_geometry = new_extent
        else:
            self._webmap.initial_state = _models_mapping.MapInitialState(
                viewpoint=_models_mapping.MapViewpoint(target_geometry=new_extent)
            )

    @property
    def zoom(self):
        """
        Get/Set the level of zoom applied to the rendered Map.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        value               Required int.
                            .. note::
                                The higher the number, the more zoomed in you are.
        ===============     ====================================================================

        :return:
            Int value that represent the zoom level

        .. code-block:: python

            # Usage example
            map.zoom = 10

        """
        return self._view_state.get("zoom", 0)

    @zoom.setter
    def zoom(self, value):
        if not isinstance(value, int):
            raise ValueError("Zoom must be an integer.")
        # When a value gets changed that affects view state we create new object to trigger the widget
        self._view_state = {
            **{key: item for key, item in self._view_state.items() if key not in {"extent", "scale"}},
            "zoom": value,
        }

    @property
    def scale(self):
        """
        Get/Set the map scale at the center of the rendered Map. If set to X, the scale
        of the map would be 1:X.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        value               Required int.
        ===============     ====================================================================

        :return: The int value of the scale

        .. code-block:: python

            # Usage example: Sets the scale to 1:24000
            map.scale = 24000

        """
        return self._view_state.get("scale", -1)

    @scale.setter
    def scale(self, value):
        if not isinstance(value, int):
            raise ValueError("Scale must be an integer.")
        # When a value gets changed that affects view state we create new object to trigger the widget
        self._view_state = {
            **{key: item for key, item in self._view_state.items() if key not in {"extent", "zoom"}},
            "scale": value,
        }

    @property
    def center(self):
        """
        Get/Set the center of the rendered Map.

        ==================     ====================================================================
        **Parameter**           **Description**
        ------------------     --------------------------------------------------------------------
        center                 A `[lat, long]` list that represents the JSON of the map
                                widget's center.
        ==================     ====================================================================

        :return: A list that represents the latitude and longitude of the map's center.

        .. code-block:: python

            # Usage example: Sets the center of the map to the given lat/long
            map.center = [34.05, -118.24]

        """
        return self._view_state.get("center", [0, 0])

    @center.setter
    def center(self, value):
        if not isinstance(value, (list, tuple)) or len(value) != 2:
            raise ValueError(
                "Center must be a list or tuple with two elements [lat, long]."
            )
        # When a value gets changed that affects view state we create new object to trigger the widget
        self._view_state = {
            **{key: item for key, item in self._view_state.items() if key != "extent"},
            "center": value,
        }

    @property
    def extent(self):
        """
        Get/Set the map's extent.

        ==================     ====================================================================
        **Parameter**           **Description**
        ------------------     --------------------------------------------------------------------
        extent                 A dictionary that represents the JSON of the map widget's extent.
        ==================     ====================================================================

        :return: A dictionary representing the map's extent.

        .. code-block:: python

            # Usage example: Sets the extent of the map to the given extent
            map.extent = {
                "xmin": -124.35,
                "ymin": 32.54,
                "xmax": -114.31,
                "ymax": 41.95
                "spatialReference": { "wkid":102100 }
            }

        """
        return (
            self._view_state.get("extent")
            or self._webmap.initial_state.viewpoint.target_geometry.dict()
        )

    @extent.setter
    def extent(self, value):
        if value and "spatialReference" not in value:
            raise ValueError("Extent must have a spatial reference.")
        # When a value gets changed that affects view state we create new object to trigger the widget
        self._view_state = {"extent": value}

    @property
    def rotation(self):
        """
        Get/Set the rotation of the rendered Map.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        value               Required int. The rotation angle in degrees.
        ===============     ====================================================================

        :return: The int value of the rotation angle

        .. code-block:: python

            # Usage example: Sets the rotation angle of the map to 45 degrees
            map.rotate = 45

        """
        return self._view_state.get("rotation", 0)

    @rotation.setter
    def rotation(self, value):
        if not isinstance(value, (int, float)):
            raise ValueError("Rotation must be a number.")
        self._view_state = {**self._view_state, "rotation": value}

    def _repr_mimebundle_(self, include=None, exclude=None, **kwargs):
        # Refresh dict incase changes made before rendering
        self._update_source()
        # Render the widget
        return super(Map, self)._repr_mimebundle_(
            include=include, exclude=exclude, **kwargs
        )

    def __add__(self, item):
        """
        Ability to add a layer to the map by using the '+' operator.
        """
        if item:
            self.content.add(item)
        else:
            return None

    def __sub__(self, index):
        """ "
        Ability to remove a layer by index using the '-' operator.
        Cannot be used to remove tables.
        """
        if isinstance(index, int):
            self.content.remove(index=index)

    def _update_source(self):
        definition = self._webmap.dict()
        center = self._view_state.get("center")
        if center is not None and "extent" not in self._view_state:
            # Seed the first view before its initial event writes state back.
            # This also avoids racing the frontend's asynchronous projection load.
            viewpoint = definition.setdefault("initialState", {}).setdefault("viewpoint", {})
            x, y = center[1], center[0]
            spatial_reference = {"wkid": 4326}
            half_span = 0.01
            if self._webmap.spatial_reference.wkid in {3857, 102100, 102113}:
                # Seed in the map's SR, as the original location helper does.
                latitude = max(-85.05112878, min(85.05112878, y))
                x = 6378137 * math.radians(x)
                y = 6378137 * math.log(math.tan(math.pi / 4 + math.radians(latitude) / 2))
                spatial_reference = self._webmap.spatial_reference.dict()
                half_span = 1000
            viewpoint["targetGeometry"] = {
                "xmin": x - half_span,
                "ymin": y - half_span,
                "xmax": x + half_span,
                "ymax": y + half_span,
                "spatialReference": spatial_reference,
            }
            # Preserve the requested scale after the initial extent is applied.
            # The standard tiled basemaps halve their scale at each zoom level.
            viewpoint["scale"] = self._view_state.get(
                "scale", 591657527.591555 / 2 ** self._view_state.get("zoom", 12)
            )
        self._webmap_dict = definition

    @property
    def content(self) -> MapContent:
        """
        Returns a MapContent object that can be used to access the layers and tables
        in the map. This is useful for adding, updating, getting, and removing content
        from the Map.
        """
        if self._content is None:
            self._content = MapContent(self)
        return self._content

    @property
    def legend(self) -> Legend:
        """
        Get an instance of the Legend class. You can use this class to enable or disable
        the legend widget. Best used inside of Jupyter Lab.
        """
        return Legend(self)

    @property
    def layer_list(self) -> LayerList:
        """
        Get an instance of the LayerList class. You can use this class to enable or disable
        the layer list widget. Best used inside of Jupyter Lab.
        """
        return LayerList(self)



_LAYER_ADAPTER = TypeAdapter(
    _models_mapping.Webmap.model_fields["operational_layers"].annotation
)


class MapContent:
    """Manage visualization layers using the existing WebMap layer models."""

    def __init__(self, map):
        self._source = map

    @property
    def layers(self):
        """Return the layer models in display order."""
        return list(self._source._webmap.operational_layers or [])

    def add(self, item, drawing_info=None, popup_info=None, index=None, options=None):
        """Add a Parquet URL, a WebMap layer dictionary, or an existing layer model."""
        if isinstance(item, str):
            url = urlsplit(item.strip())
            if url.scheme not in {"http", "https"} or not url.netloc:
                raise ValueError("Layer URLs must use HTTP or HTTPS.")
            if not url.path.lower().endswith(".parquet"):
                raise ValueError("For other URL types, pass a WebMap layer dictionary with layerType.")
            definition = {
                "layerType": "ParquetLayer",
                "source": {"type": "files", "urls": [item.strip()]},
                "title": unquote(url.path.rsplit("/", 1)[-1]),
            }
        elif isinstance(item, Mapping):
            definition = deepcopy(dict(item))
        elif isinstance(item, _models_layers.BaseModel):
            definition = item.dict()
        else:
            raise TypeError("Pass a Parquet URL, a WebMap layer dictionary, or a layer model.")

        if isinstance(options, LayerOptions):
            options = options.dict()
        options = deepcopy(dict(options or {}))
        # Match the original add method's index precedence.
        if index is not None:
            options["index"] = index
        index = options.pop("index", None)
        definition.update(options)
        definition.setdefault("id", uuid.uuid4().hex[:12])
        definition.setdefault("title", definition.get("layerType", "Layer"))
        if drawing_info:
            layer_definition = definition.setdefault("layerDefinition", {})
            layer_definition["drawingInfo"] = {
                **layer_definition.get("drawingInfo", {}), **drawing_info,
            }
        if popup_info is not None:
            definition["popupInfo"] = (
                popup_info.dict() if hasattr(popup_info, "dict") else dict(popup_info)
            )

        # Validate the same schema consumed by the existing frontend.
        layer = _LAYER_ADAPTER.validate_python([definition])[0]
        layers = self._source._webmap.operational_layers
        if any(existing.id == layer.id for existing in layers):
            raise ValueError(f"A layer with ID {layer.id!r} already exists.")
        if index is None:
            index = len(layers)
        layers.insert(index, layer)
        self._source._update_source()

    def remove(self, index=None, is_layer=True):
        if index is None:
            raise ValueError("Specify the index of the layer to remove.")
        collection = (
            self._source._webmap.operational_layers if is_layer else self._source._webmap.tables
        )
        del collection[index]
        self._source._update_source()
        return True

    def remove_all(self):
        self._source._webmap.operational_layers = []
        self._source._webmap.tables = []
        self._source._update_source()
        return True


class BasemapManager:
    def __init__(self, map):
        self._source = map

    @property
    def basemaps(self):
        return list(basemap_dict)

    @property
    def layers(self):
        return self.basemap["baseMapLayers"]

    @property
    def basemap(self):
        return self._source._webmap.base_map.dict()

    @basemap.setter
    def basemap(self, value):
        if isinstance(value, str):
            value = {"title": value, "baseMapLayers": deepcopy(basemap_dict[value])}
        self._source._webmap.base_map = _models_mapping.MapBasemap.model_validate(value)
        self._source._update_source()
